<?php
/**
 * Created by PhpStorm.
 * User: v_ypshe
 * Date: 2018/2/8
 * Time: 9:38
 */
return [
    'default' => [
        'length' => 5,
        'width' => 120,
        'height' => 36,
        'quality' =>90,
    ],
];