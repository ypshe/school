<?php
/**
 * Created by PhpStorm.
 * User: v_ypshe
 * Date: 2018/2/9
 * Time: 14:18
 */
return [
    'window'=>'F:/ffmpeg/bin/ffmpeg -i "%s" 2>&1',
    'linux'=>'/home/ffmpeg/bin/ffmpeg -i "%s" 2>&1',
];