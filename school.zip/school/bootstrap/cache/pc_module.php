<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Pc\\Providers\\PcServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Pc\\Providers\\PcServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);