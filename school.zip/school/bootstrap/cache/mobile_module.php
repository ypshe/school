<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Mobile\\Providers\\MobileServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Mobile\\Providers\\MobileServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);