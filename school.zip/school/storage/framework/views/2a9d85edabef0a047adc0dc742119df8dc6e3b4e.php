<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7">
    <meta name="description" content="" />
    <meta name="keywords" content="" />
    <meta name="author" content="" />
    <meta name="robots" content="" />
    <title><?php echo e($title); ?></title>
    <link rel="stylesheet" href="<?php echo e(URL::asset('/Pc/css/base.css')); ?>" />
    <link rel="stylesheet" href="/Pc/css/index.css" />
    <script type="text/javascript" src="/Pc/js/jquery-1.9.1.min.js"></script>
    <script type="text/javascript" src="/Pc/js/jquery.SuperSlide.2.1.1.js" ></script>
    <script type="text/javascript" src="/Pc/js/base.js"></script>
    <script type="text/javascript" src="/Vendor/layer/layer.js"></script>
    <link rel="stylesheet" href="/Pc/css/gerenzhongxin.css" />
</head>
<body>
<?php
$pros=App\Admin\Model\Profession::orderBy('sort','desc')->get()->toArray();
foreach($pros as $k=>$v){
    $pros[$k]['studies']=App\Admin\Model\Study::select('studies.*','teachers.name as tname')
        ->leftJoin('teachers','studies.tid','teachers.id')
        ->where('pid',$v['id'])->limit(6)->get();
}
$wx=\App\Admin\Model\Banner::where('place','wx')->orderBy('sort','desc')->first();
?>
<!--公共头部-->
<div class="top">
    <div class="toptext">
        <div class="logo">
            <a href="<?php echo e(url('/')); ?>">
                <img src="/Pc/img/logo.png">
            </a>
        </div>
        <div class="login" style="margin-top: 80px">
            <?php if(\Illuminate\Support\Facades\Auth::id()): ?>
                <a href="<?php echo e(url('/user')); ?>">
                    欢迎您，<?php echo e(\Illuminate\Support\Facades\Auth::user()->name); ?>

                </a>
            <?php else: ?>
                <a  href="<?php echo e(url('/login')); ?>">
                    登录
                </a>
                <span>/</span>
                <a  href="<?php echo e(url('/register')); ?>">
                    注册
                </a>
            <?php endif; ?>
            <i>
                <?php if(\Illuminate\Support\Facades\Auth::id()): ?>
                    <img onclick="javascript:window.location.href='<?php echo e(url('/user')); ?>'" width="28" height="29" src="<?php echo e(img_local(\Illuminate\Support\Facades\Auth::user()->pic)); ?>">
                <?php else: ?>
                    <img src="/Pc/img/icon02.jpg">
                <?php endif; ?>
            </i>
        </div>
    </div>
</div>
<!--导航部分-->
<div class="navbox <?php if($_SERVER['REQUEST_URI']==='/'||$_SERVER['REQUEST_URI']==='/home'): ?> indexs <?php endif; ?>">
    <div class="nav">
        <div class="navle">
            <!--全部课程-->
            <div class="allmenu">
                <i class="allmi">
                    <img src="/Pc/img/icon01.png">
                </i>
                <span class="allmenuH">全部专业</span>
                <div class="all" <?php if($_SERVER['REQUEST_URI']==='/'||$_SERVER['REQUEST_URI']==='/home'): ?>style="display: block;"<?php endif; ?>>
                    <?php $__currentLoopData = array_slice($pros,0,10); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <dl>
                            <a href="<?php echo e(url('/study/'.$v['id'])); ?>">
                                <dt>
                                    <i>
                                        <img src="<?php if($v['icon']): ?><?php echo e(img_local($v['icon'])); ?> <?php else: ?> /Pc/img/icon14.png <?php endif; ?>">
                                    </i>
                                </dt>
                                <dd>
                                    <?php echo e($v['name']); ?>

                                </dd>
                            </a>
                                <!--右边分类-->
                                <div class="allRight">
                                    <ul>
                                        <?php $__currentLoopData = $v['studies']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                <a href="">
                                                    <div class="allRightle">
                                                        <img src="<?php echo e(img_local($vv->pic)); ?>">
                                                    </div>
                                                    <div class="allRightri">
                                                        <?php echo e($vv->name); ?>

                                                        <br/><br/>
                                                        <color style="color:#999999">讲师：<?php echo e($vv->tname); ?></color>
                                                    </div>
                                                </a>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <!--右边分类-->
                        </dl>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <dl style="border-bottom: none;background:url(/Pc/img/nav_on.png) no-repeat center top;">
                        <a href="<?php echo e(url('/study')); ?>">
                            <dt>
                                <i>
                                    <img src="/Pc/img/icon14.png">
                                </i>
                            </dt>
                            <dd>
                                其他课程
                            </dd>
                        </a>
                        <!--右边分类-->
                        <div class="allRight">
                            <div class="allRighttop">
                                <?php $__currentLoopData = array_slice($pros,10); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="<?php echo e(url('study/'.$v['id'])); ?>">
                                        <?php echo e($v['name']); ?>

                                    </a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <ul>
                                <li>
                                    <a href="">
                                        <div class="allRightle">
                                            <img src="/Pc/img/img.jpg">
                                        </div>
                                        <div class="allRightri">
                                            前端进阶：响应式开发与常用框架
                                        </div>
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <!--右边分类-->
                    </dl>
                </div>
            </div>
            <!--全部课程-->
            <div class="navmo">
                <a <?php if($_SERVER['REQUEST_URI']==='/'): ?>class="on"<?php endif; ?>  href="<?php echo e(url('/')); ?>">首页</a>
                <a <?php if(strstr($_SERVER['REQUEST_URI'],'/study')!==false): ?>class="on"<?php endif; ?>  href="<?php echo e(url('/study')); ?>">培训课程</a>
                <a <?php if(strstr($_SERVER['REQUEST_URI'],'/time')!==false): ?>class="on"<?php endif; ?>  href="<?php echo e(url('/time')); ?>">学时验证</a>
                <a <?php if(strstr($_SERVER['REQUEST_URI'],'/notice')!==false): ?>class="on"<?php endif; ?>  href="<?php echo e(url('/notice')); ?>">通知公告</a>
                <a <?php if(strstr($_SERVER['REQUEST_URI'],'/work')!==false): ?>class="on"<?php endif; ?>  href="<?php echo e(url('/work')); ?>">工作动态</a>
                <a <?php if(strstr($_SERVER['REQUEST_URI'],'/help')!==false): ?>class="on"<?php endif; ?>  href="<?php echo e(url('/help/1')); ?>">帮助中心</a>
            </div>
        </div>
        <!--搜索-->
        <form class="searchbox" method="post" action="<?php echo e(url('/study?page=1')); ?>">
            <div class="search">
                <input name="search" type="text" value="<?php if(isset($search)): ?><?php echo e($search); ?><?php endif; ?>" placeholder="搜索课程" />
                <input type="hidden" name="_token" value="<?php echo csrf_token(); ?>">
                <button type="submit" id="search">
                    <img src="/Pc/img/icon03.png">
                </button>
            </div>
            <!--搜索历史-->
            <div class="searchhistory">
                <h4>热门搜索</h4>
                <a href="">UI设计</a>
                <a href="">UI设计</a>
                <a href="">UI设计</a>
                <a href="">UI设计</a>
                <a href="">UI设计</a>
                <a href="">UI设计</a>
            </div>
            <!--搜索历史-->
        </form>
        <!--搜索-->
    </div>
</div>
<!--导航部分-->

<!--banner部分-->
<?php echo $__env->yieldContent("content"); ?>
<!--公共底部-->
<div class="footer">
    <div class="footertext">
        <div class="footertextle">
            <ul>
                <li>
                    <a href="<?php echo e(url('/study')); ?>">培训课程</a>
                    <span>|</span>
                    <a href="<?php echo e(url('/time')); ?>">学时验证</a>
                    <span>|</span>
                    <a href="<?php echo e(url('/notice')); ?>">通知公告</a>
                    <span>|</span>
                    <a href="<?php echo e(url('/work')); ?>">工作动态</a>
                    <span>|</span>
                    <a href="<?php echo e(url('/help')); ?>">帮助中心</a>
                    <span>|</span>
                    <a href="<?php echo e(url('/tel')); ?>">联系我们</a>
                </li>
                <li style="margin-top:14px;margin-bottom: 14px;">
                    Copyright © 2018-2019 , All Rights Reserved
                </li>
                <li>
                    长垣职业中等专业学校继续教育培训平台  版权所有
                </li>
            </ul>
        </div>
        <div class="footertextri">
            <img src="<?php echo e(img_local($wx->src)); ?>">
            <span>微信公众号</span>
        </div>
    </div>
</div>
</body>

</html>