<?php $__env->startSection("content"); ?>
	<style>
		.yanzhengma img{
			padding-top: 2px;
		}
	</style>
	<!--banner部分-->
	<div class="banner">
		<div class="bannerbox">
			<div class="bd">
				<ul>
					<?php $__currentLoopData = $banner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<li>
							<a href="#">
								<img src="<?php echo e(img_local($v->src)); ?>">
							</a>
						</li>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</ul>
			</div>
			<div class="hd">
				<ul>
					<li></li>
					<li></li>
					<li></li>
				</ul>
			</div>
		</div>
		<!--用户登录（未登录）-->
		<?php if(!\Illuminate\Support\Facades\Auth::check()): ?>
		<div class="loginbox">
			<form method="POST" action="<?php echo e(url('login')); ?>">
				<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"/>
				<h2>
					用户登录
				</h2>
				<dl>
					<dt>身份证号：</dt>
					<dd>
						<input type="text" class="yhm" name="cardId" value="<?php echo e(old('cardId')); ?>"/>
							<span>
								<?php if($errors->has('cardId')): ?>
									<?php echo e($errors->first('cardId')); ?>

								<?php endif; ?>
							</span>
					</dd>
				</dl>
				<dl>
					<dt>密&nbsp;&nbsp;码：</dt>
					<dd>
						<input type="password" class="mimai" name="password" value="<?php echo e(old('password')); ?>"/>
						<span>
							<?php if($errors->has('password')): ?>
								<?php echo e($errors->first('password')); ?>

							<?php endif; ?>
						</span>
					</dd>
				</dl>
				<div class="yanzhengma">
					<dl>
						<dt>验证码：</dt>
						<dd>
							<input type="text" class="captcha" name="captcha" value="<?php echo e(old('captcha')); ?>">
						</dd>
					</dl>
					<img id="changeImg" src="<?php echo e(captcha_src()); ?>">
					<script>
                        $('#changeImg').click(function(){
                            $('#changeImg').attr('src','<?php echo e(captcha_src()); ?>'+Math.random());
                        });
					</script>
					<span class="yanzjieguo">
						<?php if($errors->has('captcha')): ?>
							<?php echo e($errors->first('captcha')); ?>

						<?php endif; ?>
					</span>
				</div>
				<div class="jizhu">
					<label>
						<input name="remember" type="checkbox" />
						<span>记住密码</span>
					</label>
					<a href="<?php echo e(url('/password/reset')); ?>">忘记密码？</a>
				</div>
				<div class="btn" id="dl">
					<input type="button" class="button" value="登录" />
				</div>
				<div class="jizhu">
					<a href="<?php echo e(url('/register')); ?>">还没有账号，现在注册</a>
				</div>
			</form>
		</div>
		<!--用户登录（未登录）-->
		<?php else: ?>
		<!--用户登录（已登录）-->
		<div class="loginbox">
			<h2>
				用户信息
			</h2>
			<div class="touxiang">
				<a href="<?php echo e(url('/user')); ?>">
					<img src="<?php echo e(img_local(\Illuminate\Support\Facades\Auth::user()->pic)); ?>">
				</a>
			</div>
			<h3><?php echo e(\Illuminate\Support\Facades\Auth::user()->name); ?></h3>
			<div class="tishi">
				您已成功登陆继续教育培训平台
			</div>
			<div class="other">
				<dl>
					<a href="<?php echo e(url('/user')); ?>">
						<dt>

						</dt>
						<dd>
							个人中心
						</dd>
					</a>
				</dl>
				<dl style="border-right:none">
					<a href="<?php echo e(url('/study')); ?>">
						<dt class="dt02">

						</dt>
						<dd>
							立即学习
						</dd>
					</a>
				</dl>
				<dl style="border-bottom: none;">
					<a href="<?php echo e(url('/user/reply')); ?>">
						<dt class="dt03">

						</dt>
						<dd>
							查看留言
						</dd>
					</a>
				</dl>
				<dl style="border-bottom: none;border-right:none">
					<a href="<?php echo e(url('/logout')); ?>">
						<dt class="dt04">

						</dt>
						<dd>
							退出登录
						</dd>
					</a>
				</dl>
			</div>
		</div>
		<!--用户登录（已登录）-->
		<?php endif; ?>
	</div>
		<!--主体部分-->
		<div class="main">
			<!--培训流程-->
			<div class="liucheng">
				<div class="liuchengle">
					<div class="liuchenglem">
						<img src="Pc/img/icon15.png">
						<span>培训流程</span>
					</div>
				</div>
				<div class="liuchengmo">
					<dl>
						<dt>
							<img src="Pc/img/liucheng01.png">
						</dt>
						<dd>用户注册</dd>
					</dl>
					<i>
						<img src="Pc/img/icon16.png">
					</i>
					<dl>
						<dt>
							<img src="Pc/img/liucheng02.png">
						</dt>
						<dd>报班缴费</dd>
					</dl>
					<i>
						<img src="Pc/img/icon16.png">
					</i>
					<dl>
						<dt>
							<img src="Pc/img/liucheng03.png">
						</dt>
						<dd>在线学习</dd>
					</dl>
					<i>
						<img src="Pc/img/icon16.png">
					</i>
					<dl>
						<dt>
							<img src="Pc/img/liucheng04.png">
						</dt>
						<dd>在线练习</dd>
					</dl>
					<i>
						<img src="Pc/img/icon16.png">
					</i>
					<dl>
						<dt>
							<img src="Pc/img/liucheng05.png">
						</dt>
						<dd>在线考试</dd>
					</dl>
					<i>
						<img src="Pc/img/icon16.png">
					</i>
					<dl>
						<dt>
							<img src="Pc/img/liucheng06.png">
						</dt>
						<dd>档案记载</dd>
					</dl>
				</div>
				<div class="liuchengri">
					<a href="#">
						<h2>报名表格下载</h2>
						<span>直接点击下载即可</span>
					</a>
				</div>
			</div>
			<!--培训流程-->
			<!--精品课程-->
			<div class="jingpinke">
				<div class="title">
					<h2>精品课程</h2>
					<div class="titletab">
						<a class="on" href="">
							全部
						</a>
						<?php $__currentLoopData = $data['proSix']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<a href="<?php echo e(url('study/'.$v['id'])); ?>">
								<?php echo e($v['name']); ?>

							</a>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
					<div class="titlemore">
						<a href="<?php echo e(url('/study')); ?>">
							<img src="Pc/img/icon18.png">
						</a>
					</div>
				</div>
				<div class="protext">
					<?php $__currentLoopData = $data['studies']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<dl>
							<a href="<?php echo e(url('/studyDesc/'.$v->id)); ?>">
								<dt>
									<img src="<?php echo e(img_local($v->pic)); ?>">
								</dt>
								<dd>
									<h4 title="<?php echo e($v->name); ?>"><?php echo e($v->name); ?></h4>
									<span>讲师：<?php echo e($v->tname); ?></span>
									<span>职务：<?php echo e($v->twork); ?></span>
								</dd>
							</a>
						</dl>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			</div>
			<!--精品课程-->
			<!--通知公告、工作动态、培训指南-->
			<div class="mainbo">
				<div class="gonggao">
					<div class="title">
						<h2>通知公告</h2>
						<div class="titlemore">
							<a href="<?php echo e(url('/notice')); ?>">
								<img src="Pc/img/icon18.png">
							</a>
						</div>
					</div>
					<div class="nbanner">
						<a href="#">
							<img src="Pc/img/gonggao.jpg">
						</a>
					</div>
					<div class="new">
						<?php $__currentLoopData = $notices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<dl>
								<a title="<?php echo e($v->title); ?>" href="<?php echo e(url('/notice/'.$v->id)); ?>">
									<dt><?php echo e($v->title); ?></dt>
									<dd>[<?php echo e(date('Y-m-d',strtotime($v->created_at))); ?>]</dd>
								</a>
							</dl>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
				</div>
				<div class="gonggao dongtai">
					<div class="title">
						<h2>工作动态</h2>
						<div class="titlemore">
							<a href="<?php echo e(url('/work')); ?>">
								<img src="Pc/img/icon18.png">
							</a>
						</div>
					</div>
					<div class="nbanner">
						<a href="#">
							<img src="Pc/img/dongtai.jpg">
						</a>
					</div>
					<div class="new">
						<?php $__currentLoopData = $works; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<dl>
								<a title="<?php echo e($v->title); ?>" href="<?php echo e(url('/work/'.$v->id)); ?>">
									<dt><?php echo e($v->title); ?></dt>
									<dd>[<?php echo e(date('Y-m-d',strtotime($v->created_at))); ?>]</dd>
								</a>
							</dl>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
				</div>
				<div class="zhinan">
					<div class="peixun">
						<div class="peititle">
							<img src="Pc/img/icon17.png">
							<span>培训指南</span>
						</div>
						<div class="peixunb">
							<a href="<?php echo e(url('/help/1')); ?>">
								培训<br>流程
							</a>
							<a style="margin-left:27px;margin-right: 28px;" href="<?php echo e(url('/help/3')); ?>">
								培训<br>须知
							</a>
							<a  href="<?php echo e(url('/help/2')); ?>">
								操作<br>演示
							</a>
						</div>
					</div>
					<div class="peixun mingdan">
						<div class="peititle">
							<img src="Pc/img/icon19.png">
							<span>最新考试通过名单</span>
						</div>
						<div class="mingdanb">
							<div class="mingdanbtop">
								<span>地区</span>
								<span style="text-align: center;">姓名</span>
								<span style="width:98px;text-align: right;">通过时间</span>
							</div>
							<div class="mingdanbbo">
								<div class="bd">
									<ul>
										<li>
											<span>长垣县</span>
											<span style="text-align: center;">王安利</span>
											<span style="width:98px;text-align: right;">2017-12-25</span>
										</li>
										<li>
											<span>长垣县</span>
											<span style="text-align: center;">王安利</span>
											<span style="width:98px;text-align: right;">2017-12-25</span>
										</li>
										<li>
											<span>长垣县</span>
											<span style="text-align: center;">王安利</span>
											<span style="width:98px;text-align: right;">2017-12-25</span>
										</li>
										<li>
											<span>长垣县</span>
											<span style="text-align: center;">王安利</span>
											<span style="width:98px;text-align: right;">2017-12-25</span>
										</li>
										<li>
											<span>长垣县</span>
											<span style="text-align: center;">王安利</span>
											<span style="width:98px;text-align: right;">2017-12-25</span>
										</li>
										<li>
											<span>长垣县</span>
											<span style="text-align: center;">王安利</span>
											<span style="width:98px;text-align: right;">2017-12-25</span>
										</li>
										<li>
											<span>长垣县</span>
											<span style="text-align: center;">王安利</span>
											<span style="width:98px;text-align: right;">2017-12-25</span>
										</li>
										<li>
											<span>长垣县</span>
											<span style="text-align: center;">王安利</span>
											<span style="width:98px;text-align: right;">2017-12-25</span>
										</li>
										<li>
											<span>长垣县</span>
											<span style="text-align: center;">王安利</span>
											<span style="width:98px;text-align: right;">2017-12-25</span>
										</li>
										<li>
											<span>长垣县</span>
											<span style="text-align: center;">王安利</span>
											<span style="width:98px;text-align: right;">2017-12-25</span>
										</li>
									</ul>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<!--通知公告、工作动态、培训指南-->
		</div>
		<!--主体部分-->

		<!--表单验证-->
		<script type="text/javascript">
		var s = /^\d{15}|\d{17}[xX]{1}$/; //验证身份证
		var d = /^[a-zA-Z0-9]{6,18}$/;//验证密码
		var status=1;
		$("[name='name']").blur(function() {
			var v = $(this).val();
			if (v == '') {
				$(this).next("span").html("身份证不能为空！");
                status=0;
			}else if(!v.match(s)){
				$(this).next("span").html("身份证不合法！");
                status=0;
            }else{
				$(this).next("span").html("");
			} 
		});
		$("[name='yan']").blur(function() {
			var v = $(this).val();
			if (v == '') {
				$(this).parents(".yanzhengma").children("span").html("验证码不能为空！");
                status=0;
            }else{
				$(this).parents(".yanzhengma").children("span").html("");
			} 
		});
		$("[name='mima']").blur(function() {
			var v = $(this).val();
			if (v == '') {
				$(this).next("span").html("密码不能为空！");
                status=0;
            }else if(!v.match(d)){
				$(this).next("span").html("密码不合法！");
                status=0;
            }else{
				$(this).next("span").html("");
			} 
		});
		//点击登录之后
		$('#dl').click(function(){
			var name = $(this).parent("form").find(".yhm").val();
			var yan = $(this).parent("form").find(".captcha").val();
			var mima = $(this).parent("form").find(".mimai").val();
			var status =1;
			if (name=="") {
				$(this).parent("form").find(".yhm").next("span").html("身份证号不能为空");
                status=0;
            }else if(!name.match(s)){
				$(this).parent("form").find(".yhm").next("span").html("请输入正确格式的身份证号");
                status=0;
            }else{
				$(this).parent("form").find(".yhm").next("span").html("");
			};
			if (yan == "") {
				$(this).parent("form").find(".yanzjieguo").html("验证码不能为空");
                status=0;
            }else{
				$(this).parent("form").find(".yanzjieguo").html("");
			};
			
			
			if (mima == "") {
				$(this).parent("form").find(".mimai").next("span").html("密码不能为空");
                status=0;
            }else if(!mima.match(d)){
				$(this).parent("form").find(".mimai").next("span").html("请输入正确的密码");
                status=0;
            }else{
				$(this).parent("form").find(".mimai").next("span").html("");
			}
			if(status==1){
                $(this).parent("form").submit();
			}
		});

		</script>
		<!--表单验证-->
		<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>