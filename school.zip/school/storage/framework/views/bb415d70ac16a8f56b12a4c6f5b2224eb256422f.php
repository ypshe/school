<?php $__env->startSection('content'); ?>
		<!--主体部分-->
		<div class="main">
			<!--面包屑导航-->
			<div class="mianbao">
				<a href="<?php echo e(url('/')); ?>">首页</a>
				<span>></span>
				<a href="<?php echo e(url('/study')); ?>">培训课程</a>
				<span>></span>
				<a href="">培训课程详情</a>
			</div>
			<!--面包屑导航-->
			<!--精英班-->
			<div class="bantop">
				<div class="bantople">
					<h2><?php echo e($study->name); ?></h2>
					<div class="keshi">
						<ul>
							<li>
								<span>学习人数</span>
								<span><?php echo e($study->study_num); ?></span>
							</li>
							<li style="width: 107px">
								<span>课程时长</span>
								<span><?php echo e(intval($study->time/(60*60))); ?>小时<?php echo e((intval($study->time/60)-intval($study->time/(60*60)))); ?>分<?php echo e(intval($study->time%(60))); ?>秒</span>
							</li>
							<li>
								<span>综合评分</span>
								<span><?php echo e($study->grade); ?></span>
							</li>
						</ul>
					</div>
				</div>
				<div class="bantopri">
					<div class="bantopritop">
						<a class="goStudy" url=""<?php if($define===0): ?><?php echo e(url('/videoFirst/'.$study->id)); ?><?php else: ?><?php echo e(url('/getStudy/'.$study->id)); ?><?php endif; ?>"><?php if($define===0): ?>开始学习<?php else: ?>立即报名<?php endif; ?></a>
					</div>
				</div>
			</div>
			<!--精英班-->
			<!--简介-->
			<div class="jianjie">
				<div class="jianjiele">
					<div class="title">
						<h2>课程简介</h2>
					</div>
					<div class="jianjietext">
						简介：<?php echo e($study->desc); ?>

					</div>
					<div class="title">
						<h2>课程目录</h2>
					</div>
					<div class="mulubox">
						<?php $__currentLoopData = $section; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<dl>
								<dt>
									<span>第<?php echo e($k+1); ?>章 <?php echo e($v); ?> </span>
									<i></i>
								</dt>
								<?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kk=>$vv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php if($vv->section==$k): ?>
										<dd>
											<a class="goStudy" url="<?php if($define===0): ?><?php echo e(url('/video/'.$vv->id)); ?><?php else: ?><?php echo e(url('/getStudy/'.$study->id)); ?><?php endif; ?>">
												<div class="mululist">
													<i></i>
													<span><?php echo e($k+1); ?>-<?php echo e($vv->sort); ?> <?php echo e($vv->name); ?>（<?php echo e(intval($vv->time/60)); ?>：<?php echo e(intval($vv->time%60)); ?>） </span>
													<b><?php if($define===0): ?>开始学习<?php else: ?>立即报名<?php endif; ?></b>
												</div>
											</a>
										</dd>
									<?php endif; ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</dl>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
					<script>
						$('.goStudy').click(function(){
						    <?php if(!\Illuminate\Support\Facades\Auth::check()): ?>
                                layer.msg('请登录后进行课程学习！', {time: 3000, icon:3});
                                var url=$(this).attr('url');
                            	setTimeout(function() {
                                    location.href=url;
								},2000);
							<?php else: ?>
                                location.href=$(this).attr('url');
                            <?php endif; ?>
						});
					</script>
				</div>
				<!--讲师简介-->
				<div class="jianjieri">
					<div class="jianjieritop">
						<div class="title">
							<h2>讲师简介</h2>
						</div>
						<div class="jianjiebox">
							<h4><?php echo e($study->tname); ?></h4>
							<span> <?php echo e($study->twork); ?></span>
							<b><?php echo e(mb_substr($study->tdesc,0,80,'utf-8')); ?><?php echo e((mb_strlen($study->tdesc,'utf-8')>80)? '...':''); ?></b>
						</div>
					</div>
					<div class="jianjieribo">
						<div class="title">
							<h2>推荐课程</h2>
						</div>
						<div class="kechengbox">
							<?php $__currentLoopData = $orderStudy; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<dl>
									<a href="<?php echo e(url('/studyDesc/'.$v->id)); ?>">
										<dt>
											<img src="<?php echo e(img_local($v->pic)); ?>">
										</dt>
										<dd>
											<span><?php echo e($v->name); ?></span>
											<b>讲师：<?php echo e($v->tname); ?></b>
										</dd>
									</a>
								</dl>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
					</div>
				</div>
				<!--讲师简介-->
			</div>
			<!--简介-->
		</div>
		<!--主体部分-->
		<!--公共底部-->
		<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>