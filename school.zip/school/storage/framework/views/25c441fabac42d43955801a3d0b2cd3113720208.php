<?php $__env->startSection('content'); ?>
		<!--主体部分-->
		<div class="main">
			<!--面包屑导航-->
			<div class="mianbao">
				<a href="<?php echo e(url('/')); ?>">首页</a>
				<span>></span>
				<a href="<?php echo e(url('/study')); ?>">培训课程</a>
			</div>
			<!--面包屑导航-->
			<!--课程列表-->
			<div class="jingpinke kechenglist">
				<div class="title">
					<h2>专业：</h2>
					<div class="titletab">
						<?php $__currentLoopData = $data['pro']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<a <?php if(isset($pid)&&$pid==$v->id): ?> class="on" <?php endif; ?> href="<?php echo e(url('/study/'.$v->id)); ?>">
								<?php echo e($v->name); ?>

							</a>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
				</div>
			</div>
			<div class="protext protextli">
				<?php $__currentLoopData = $data['studies']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<dl>
						<a href="<?php echo e(url('/studyDesc/'.$v->id)); ?>">
							<dt>
								<img src="<?php echo e(img_local($v->pic)); ?>">
							</dt>
							<dd>
								<h4 title="<?php echo e($v->name); ?>"><?php echo e($v->name); ?></h4>
								<span>讲师：<?php echo e($v->tname); ?></span>
								<span>职务：<?php echo e($v->twork); ?></span>
							</dd>
						</a>
					</dl>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
        <?php echo $data['studies']->render(); ?>
		</div>
		<!--主体部分-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>