<?php $__env->startSection('content'); ?>
	<!--导航部分-->
	<!--主体部分-->
	<div class="main">
		<!--面包屑导航-->
		<div class="mianbao">
			<a href="<?php echo e(url('/')); ?>">首页</a>
			<span>></span>
			<a href="<?php echo e(url('/work')); ?>">工作动态</a>
		</div>
		<!--面包屑导航-->
		<!--通知公告-->
		<div class="jingpinke tongzhi">
			<?php $__currentLoopData = $works; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<dl>
					<a href="<?php echo e(url('/notice/'.$v->id)); ?>">
						<dt>
						<div>
							<div style=" float:left;width:140px;height: 100px" ><img style="width:140px;height: 100px" src="<?php echo e(img_local($v->pic)); ?>" alt="查看详情"></div>
							<div style="padding-left:160px">
								<h3><?php echo e($v->title); ?></h3>
								<span style="height:auto">发布人：<?php echo e($v->showAuthor); ?><br>发布时间：<?php echo e($v->created_at); ?></span>
								
							</div>
							<span style="height:auto">概要：<?php echo e($v->blurb); ?></span>
						</div>
						</dt>
						<dd>
							<span>查看详情</span>
						</dd>
					</a>
				</dl>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php echo $works->render();?>
		</div>
		<!--通知公告-->
	</div>
	<!--主体部分-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>