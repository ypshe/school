<?php if($paginator->hasPages()): ?>
    <div class="page">
        
        <?php if($paginator->onFirstPage()): ?>
            <span class="disabled">首页</span>
        <?php else: ?>
            <span><a href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev">首页</a></span>
        <?php endif; ?>

        
        <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
            <?php if(is_string($element)): ?>
                <span class="disabled"><?php echo e($element); ?></span>
            <?php endif; ?>

            
            <?php if(is_array($element)): ?>
                <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($page == $paginator->currentPage()): ?>
                        <a href="" class="on"><?php echo e($page); ?></a>
                    <?php else: ?>
                        <a href="<?php echo e($url); ?>"><?php echo e($page); ?></a>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        
        <?php if($paginator->hasMorePages()): ?>
            
            <span><a href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next">尾页</a></span>
        <?php else: ?>
            <span class="disabled">尾页</span>
        <?php endif; ?>
    </div>
<?php endif; ?>
