<!DOCTYPE html>
<html>

	<head>
		<meta charset='utf-8'>
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
		<meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7">
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<meta name="author" content="" />
		<meta name="robots" content="" />
		<title>视频播放</title>
		<link rel="stylesheet" href="/Pc/css/base.css" />
		<link rel="stylesheet" href="/Pc/css/index.css" />
	</head>

	<body>
		<div class="videobox">
			<div class="videoboxtop">
				<div class="videoboxtople">
					<a href="<?php echo e(url('/studyDesc/'.$study->id)); ?>">
						<img src="/Pc/img/fanhui.png">
						<b><?php echo e($study->name); ?></b>
						<span><?php echo e($video->section+1); ?>-<?php echo e($video->sort); ?><?php echo e($video->name); ?></span>
					</a>
				</div>
				<div class="videoboxtopri">
					<a href="<?php echo e(url('/user')); ?>">
						<img src="<?php echo e(img_local(\Illuminate\Support\Facades\Auth::user()->pic)); ?>">
					</a>
				</div>
			</div>
			<!--中间弹出问题-->
			<?php if($question): ?>
				<div class="wenti">
				<div class="title">
					<h2>请回答当前问题并继续观看课程</h2>
				</div>
				<div class="wentib">
					<h3>01. <?php echo e($question->info); ?>？</h3>
					<ul>
						<li>
							<label>
									<a>
										<i></i>
										<input type="radio" name="probrem"  value="<?php echo e($question->choose_1); ?>"/>
									</a>
									<span><i>A.</i><?php echo e($question->choose_1); ?></span>
								</label>
						</li>
						<li>
							<label>
									<a>
										<i></i>
										<input type="radio" name="probrem"  value="<?php echo e($question->choose_2); ?>"/>
									</a>
									<span><i>B.</i><?php echo e($question->choose_2); ?></span>
								</label>
						</li>
						<li>
							<label>
									<a>
										<i></i>
										<input type="radio" name="probrem"  value="<?php echo e($question->choose_3); ?>"/>
									</a>
									<span><i>C.</i><?php echo e($question->choose_3); ?></span>
								</label>
						</li>
						<li>
							<label>
									<a>
										<i></i>
										<input type="radio" name="probrem"  value="<?php echo e($question->choose_4); ?>"/>
									</a>
									<span><i>D.</i><?php echo e($question->choose_4); ?></span>
								</label>
						</li>
					</ul>
					<div class="btnbox">
						<div class="btn redbtn" id="queding">
							<input type="button" value="确定" />
						</div>
					</div>
				</div>
				<!--回答正确-->
				<div class="zhengque" id="zhengque">
					<img src="/Pc/img/zhengque.png">
					<span>恭喜您回答正确，请继续观看</span>
					<a class="btn lv jixu" href="javascript:;" >
						请继续
					</a>
				</div>
				<!--回答正确-->
				<!--回答错误-->
				<div class="zhengque" id="cuowu">
					<img src="/Pc/img/cuowu.png">
					<span>很抱歉回答错误，正确答案为<b><?php echo e($question->select); ?>.<?php echo e($question->true); ?></b></span>
					<span>请继续观看</span>
					<a class="btn lv jixu" href="javascript:;" >请继续</a>
				</div>
				<!--回答错误-->
			</div>
			<?php endif; ?>
			<!--中间弹出问题-->
			<div class="video" onclick="playPause()">
				<div class="bofang">
					<img src="/Pc/img/bofang.png">
				</div>
				<video style="width:100%;height:95%;" id="video" controls="controls">

					<source src="<?php echo e(img_local($video->url)); ?>" type="video/ogg" />
					<source src="<?php echo e(img_local($video->url)); ?>" type="video/mp4" />
					<source src="<?php echo e(img_local($video->url)); ?>" type="video/webm" />
					<object data="" style="width:100%;height:95%;">
				            <embed width="386" height="386" src="" />
				    </object>
				</video>

			</div>
			<div class="section-list" style="right: 0px;">
				<div class="nano has-scrollbar">
					<div class="nano-content" tabindex="0" style="right: -17px;">
						<h3><?php echo e($study->name); ?></h3>
						<?php $__currentLoopData = $section; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<ul>
								<li class="sec-title">
									<span>第<?php echo e($k+1); ?>章 <?php echo e($v); ?></span>
								</li>
								<?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kk=>$vv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php if($vv->section==$k): ?>
										<li>
											<a href="<?php echo e(url('/video/'.$vv->id)); ?>"  <?php if($vv->id==$video->id): ?> class="on" <?php endif; ?>>
												<i class="icon"><img src="/Pc/img/xiaoyoujian.png"></i>
												<i><?php echo e($k+1); ?>-<?php echo e($vv->sort); ?></i> <b><?php echo e($vv->name); ?></b><i><?php if($vv->id==$video->id): ?>onlive <?php else: ?> <?php echo e(intval($vv->time/60)); ?>:<?php echo e(intval($vv->time%60)); ?><?php endif; ?></i>
											</a>
										</li>
									<?php endif; ?>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</ul>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
				</div>
			</div>
		</div>
		<!--遮罩层-->
		
		<!--遮罩层-->
		<script type="text/javascript" src="/Pc/js/jquery-1.9.1.min.js"></script>
		<script type="text/javascript" src="/Pc/js/jquery.SuperSlide.2.1.1.js"></script>
		<script type="text/javascript" src="/Pc/js/base.js"></script>
		<script>
			<?php if($question): ?>
				function playPause() {
					var myVideo = $(".video").children("video")[0];
					if(myVideo.paused) {
						myVideo.play(); //视频播放
						setTimeout(function() {
							$(".wenti").show();
							$(".zhe").show();
							myVideo.pause(); //视频停止
						}, <?php echo e(($video->time/2)*1000); ?>);
						$("#queding").click(function() {
							if($("input[name='probrem']:checked").val()=='<?php echo e($question->true); ?>'){
								$("#zhengque").show();
							}else{
								if(1){
									$.ajax({
										type: 'POST',
										url: '/ajax/userError',
										data: {eid:<?php echo e($question->id); ?>,error:$("input[name='probrem']:checked").val()},
										dataType: "json"
									});
								}
								$("#cuowu").show();
							}
							myVideo.pause(); //视频停止
						});
						$(".jixu").click(function(){
							$.ajax({
								type: 'POST',
								url: '/ajax/userStudy',
								data: {vid:<?php echo e($video->id); ?>,res:0},
								dataType: "json",
								success:function(){
									$(".wenti").hide();
									$("#zhengque").hide();
									$("#cuowu").hide();
									$(".zhe").hide();
									myVideo.play();
								}
							});
						});
						$(".video").find(".bofang").hide();
					} else {
						myVideo.pause(); //视频停止
						$(".video").find(".bofang").show();
					}
				}
			<?php else: ?>
            function playPause() {
                var myVideo = $(".video").children("video")[0];
                if(myVideo.paused) {
                    myVideo.play(); //视频播放
                    $(".video").find(".bofang").hide();
                } else {
                    myVideo.pause(); //视频停止
                    $(".video").find(".bofang").show();
                }
            }
			<?php endif; ?>
            /*视频结束或错误*/
            $("#video").bind('error ended', function(){
                $.ajax({
                    type: 'POST',
                    url: '/ajax/userStudy',
                    data: {vid:<?php echo e($video->id); ?>,res:1},
                    dataType: "json"
                });
            });
		</script>
	</body>

</html>