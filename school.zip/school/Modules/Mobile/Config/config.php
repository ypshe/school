<?php

return [
    'name' => 'Mobile'
];
